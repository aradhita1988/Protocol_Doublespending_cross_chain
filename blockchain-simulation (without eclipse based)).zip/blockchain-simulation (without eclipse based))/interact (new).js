// Import required libraries
const Web3 = require('web3');

// Two Ganache instances
const web3Main = new Web3('http://localhost:7545'); // Ganache instance for Cmain + SC
const web3Side = new Web3('http://localhost:7546'); // Ganache instance for Cside

// Contract addresses + ABIs
const Cmainaddress = "0x777BBDf6a5ebA52e3fef8EA7275C64ff52216588"; 
const CmainABI = require('./build/contracts/Cmain.json').abi;

const Csideaddress = "0x3Be6FEc1248E6fF516605691dA4B58cB53518513"; 
const CsideABI = require('./build/contracts/Cside.json').abi;

const SCaddress = "0x1c2574F86464b8bC656A42395B255F8F761241b6"; 
const SCABI = require('./build/contracts/SC.json').abi;

// Contract instances
const Cmain = new web3Main.eth.Contract(CmainABI, Cmainaddress);
const SC = new web3Main.eth.Contract(SCABI, SCaddress);
const Cside = new web3Side.eth.Contract(CsideABI, Csideaddress);

// Users (⚠️ make sure they exist in the correct Ganache instance)
const user1Address = '0xeecCb56E7dbA65664cB2C0EfEB8fAe618e125C42'; // on Ganache 7545
const user2Address = '0x55CCE0b6c804F3FdDB7C2ad85be586993879aD98'; // on Ganache 7545
const user3Address = '0xAE12bECb24d6DD0e915EE155342F6759EF6C6189'; // on Ganache 7546

async function runScenario(scenarioId) {
    const primeP = 37; // Example prime number

    console.log(`Running scenario ${scenarioId}...`);

    let userIncome = 10; // Initialize User1's income (default to 10)

    // Step 1: User1 requests secret key from SC
    await Cmain.methods.requestSecretKey(user1Address).send({ from: user1Address });
    // Step 2: SC generates a secret key and sends it to Cmain along with registration information
    const secretKey = Math.floor(Math.random() * (primeP - 1)) + 1;  
    const timestamp = Date.now();
    await SC.methods.registerKey(user1Address, secretKey, timestamp).send({
        from: user1Address,
        gas: 3000000
    });
    
    // Step 3: Generate ECDSA key and sign
    const secretKeyHex = '0x' + BigInt(secretKey).toString(16).padStart(64, '0'); 
    try {
        const account = web3Main.eth.accounts.privateKeyToAccount(secretKeyHex);
        console.log(`Account Address: ${account.address}`);

        const message = 'Transaction Data';
        const signature = await web3Main.eth.accounts.sign(message, secretKeyHex);
        console.log(`Generated signature: ${JSON.stringify(signature)}`);
    } catch (error) {
        console.error(`Error occurred: ${error.message}`);
    }

    // Step 5: Sending transactions to User2 and User3
    const amount = web3Main.utils.toWei('0.1', 'ether');
    const packedData = web3Main.eth.abi.encodeFunctionCall({
        name: 'transfer',
        type: 'function',
        inputs: [
            { type: 'address', name: 'recipient' },
            { type: 'uint256', name: 'amount' }
        ]
    }, [user2Address, amount]);
    await Cmain.methods.sendTransaction(user2Address, packedData).send({ from: user1Address });
    await Cmain.methods.sendTransaction(user3Address, packedData).send({ from: user1Address });

    // Step 6: User3 generates an encrypted audit report
    const encryptedData = encryptDataWithPaillier(packedData);
    await Cside.methods.sendEncryptedAuditReport(user3Address, encryptedData).send({ from: user3Address });
    
    // Step 7: SC receives and checks consistency
    const data = 'Audit Report Data';
    const auditReportHash = web3Main.utils.keccak256(data);

    const gasEstimate = await SC.methods.registerKey(user3Address, secretKey, timestamp).estimateGas({ from: user3Address });
    await SC.methods.registerKey(user3Address, secretKey, timestamp).send({ from: user3Address, gas: gasEstimate });

    const gasEstimate2 = await SC.methods.registerKey(user2Address, secretKey, timestamp).estimateGas({ from: user2Address });
    await SC.methods.registerKey(user2Address, secretKey, timestamp).send({ from: user2Address, gas: gasEstimate2 });

    const gasEstimate1 = await SC.methods.registerKey(user1Address, secretKey, timestamp).estimateGas({ from: user1Address });
    await SC.methods.registerKey(user1Address, secretKey, timestamp).send({ from: user1Address, gas: gasEstimate1 });

    const auditLog = await SC.methods.auditLogs(user3Address).call();
    await SC.methods.setExpectedHash(data).send({ from: user3Address, gas: 3000000 });

    const auditData = await SC.methods.receiveAuditReport(data, auditReportHash).call({ from: user3Address });
    const receivedData = await SC.methods.receiveDataFromUser(user1Address).call();
    const isConsistent = checkConsistency(auditData, receivedData);

    if (!isConsistent) {
        await SC.methods.sendBlockNotification(user1Address, 'Double-spending detected').send({ from: user1Address });
        console.log('Double-spending detected!');
        userIncome = 0;
    }

    // Step 9: User2 audit report
    const data2= 'User2 Audit Report Data';
    const user2AuditReportHash = web3Main.utils.keccak256(data2);
    const auditData1 = await SC.methods.receiveAuditReport(data2, user2AuditReportHash).call({ from: user2Address });

    // Step 10: Compare signatures
    const user1Signature = await SC.methods.getSignature(user1Address).call();
    const user2Signature = await SC.methods.getSignature(user2Address).call();
    if (user1Signature === user2Signature) {
        await SC.methods.sendBlockNotification(user1Address, 'Detected double-spending attempt').send({ from: user1Address });
        console.log('Double-spending detected, User1\'s income is 0');
        userIncome = 0;
    } else {
        console.log('No double-spending detected');
    }

    // Step 12: Timestamp manipulation (random chance)
    const randomChance = Math.random();
    const timestampManipulationOccurs = randomChance < 0.3;  

    if (timestampManipulationOccurs) {
        const manipulatedTimestamp = Date.now();
        const timestampDifference = Math.abs(timestamp - manipulatedTimestamp);
        const allowedTimestampDifference = 1000; 
        if (timestampDifference < allowedTimestampDifference) {
            console.log('Timestamp manipulation detected!');
            userIncome = 20;  
        }
    }

    console.log(`Total income for User1 in scenario ${scenarioId}: ${userIncome}`);
}

// Helper functions
function encryptDataWithPaillier(data) {
    return web3Main.utils.sha3(JSON.stringify(data)); 
}
function checkConsistency(auditData, receivedData) {
    return auditData === receivedData;
}

// Run scenarios
async function runMultipleScenarios() {
    for (let i = 1; i <= 4; i++) {
        await runScenario(i);
    }
}
runMultipleScenarios();

