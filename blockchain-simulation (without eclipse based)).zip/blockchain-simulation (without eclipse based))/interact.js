// Import required libraries
const Web3 = require('web3');
const web3 = new Web3('http://localhost:7545'); // Example connection to Ganache


const Cmainaddress = "0x777BBDf6a5ebA52e3fef8EA7275C64ff52216588"; // Cmain contract address
const CmainABI = require('./build/contracts/Cmain.json').abi;

const Csideaddress = "0x3Be6FEc1248E6fF516605691dA4B58cB53518513"; // Cmain contract address
const CsideABI = require('./build/contracts/Cside.json').abi;


const SCaddress = "0x1c2574F86464b8bC656A42395B255F8F761241b6"; // SC contract address
const SCABI = require('./build/contracts/SC.json').abi;
// Example contract instances (replace with actual contract instances)
const Cmain = new web3.eth.Contract(CmainABI, Cmainaddress);
const Cside = new web3.eth.Contract(CsideABI, Csideaddress);
const SC = new web3.eth.Contract(SCABI, SCaddress);

const user1Address = '0xeecCb56E7dbA65664cB2C0EfEB8fAe618e125C42';
const user2Address = '0x55CCE0b6c804F3FdDB7C2ad85be586993879aD98';
const user3Address = '0xAE12bECb24d6DD0e915EE155342F6759EF6C6189';

async function runScenario(scenarioId) {
    const primeP = 37; // Example prime number

    console.log(`Running scenario ${scenarioId}...`);

    let userIncome = 10; // Initialize User1's income (default to 10)

    // Step 1: User1 requests secret key from SC
    await Cmain.methods.requestSecretKey(user1Address).send({ from: user1Address });
    // Step 2: SC generates a secret key and sends it to Cmain along with registration information
    const secretKey = Math.floor(Math.random() * (primeP - 1)) + 1;  // Random key in range 1 to P-1
    const timestamp = Date.now();
    await SC.methods.registerKey(user1Address, secretKey, timestamp).send({
        from: user1Address,
        gas: 3000000 // Adjust this value as needed
    });
    

    // Step 3: User1 generates ECDSA signature using private key and secret key

    //const secretKey = Math.floor(Math.random() * (primeP - 1)) + 1; // Random key in range 1 to P-1
const secretKeyHex = '0x' + BigInt(secretKey).toString(16).padStart(64, '0'); // Convert to valid private key format

//console.log(`Generated secret key (decimal): ${secretKey}`);
//console.log(`Generated secret key (hex): ${secretKeyHex}`);
// Verify private key validity
try {
    const account = web3.eth.accounts.privateKeyToAccount(secretKeyHex);
    console.log(`Account Address: ${account.address}`);
} catch (err) {
    console.error(`Private key validation failed: ${err.message}`);
}

// Step 3: User1 generates ECDSA signature using the private key and secret key
const message = 'Transaction Data';
const amount = web3.utils.toWei('0.1', 'ether');
//const signature = await web3.eth.accounts.sign(message, secretKeyHex); // Generate signature
//console.log(`Generated signature: ${JSON.stringify(signature)}`);

    // Step 4: Packing timestamp, data, public key of User1, and the signature
    try {
        //console.log(`Type of privateKey before signing: ${typeof secretKeyHex}`);
        //console.log(`Value of privateKey before signing: ${secretKeyHex}`);
        
        // Validate the key before signing
        const account = web3.eth.accounts.privateKeyToAccount(secretKeyHex);
        //console.log(`Account Address: ${account.address}`);

        const signature = await web3.eth.accounts.sign(message, secretKeyHex);
        //console.log(`Generated signature: ${JSON.stringify(signature)}`);
    } catch (error) {
        console.error(`Error occurred: ${error.message}`);
    }
    // Step 5: Sending transactions to User2 and User3
    const packedData = web3.eth.abi.encodeFunctionCall({
        name: 'transfer', // Adjust to your contract function
        type: 'function',
        inputs: [
            { type: 'address', name: 'recipient' },
            { type: 'uint256', name: 'amount' }
        ]
    }, [user2Address, amount]);
    await Cmain.methods.sendTransaction(user2Address, packedData).send({ from: user1Address });
    await Cmain.methods.sendTransaction(user3Address, packedData).send({ from: user1Address });

    // Step 6: User3 generates an encrypted audit report (Paillier encryption placeholder)
    const encryptedData = encryptDataWithPaillier(packedData);  // Paillier encryption placeholder
    
    await Cside.methods.sendEncryptedAuditReport(user3Address, encryptedData).send({ from: user3Address });
    
    // Step 7: SC receives and checks consistency of the audit report
    const data = 'Audit Report Data';
    const auditReportHash = web3.utils.keccak256(data);
    //console.log("Audit Report Hash (JS):", auditReportHash);
    const gasEstimate = await SC.methods.registerKey(user3Address, secretKey, timestamp).estimateGas({ from: user3Address });
   //console.log(`Gas estimate: ${gasEstimate}`);

await SC.methods.registerKey(user3Address, secretKey, timestamp).send({
    from: user3Address,
    gas: gasEstimate
});
const gasEstimate2 = await SC.methods.registerKey(user2Address, secretKey, timestamp).estimateGas({ from: user2Address });
   //console.log(`Gas estimate2: ${gasEstimate2}`);

await SC.methods.registerKey(user2Address, secretKey, timestamp).send({
    from: user2Address,
    gas: gasEstimate2
});

const gasEstimate1 = await SC.methods.registerKey(user1Address, secretKey, timestamp).estimateGas({ from: user1Address });
   //console.log(`Gas estimate2: ${gasEstimate1}`);

await SC.methods.registerKey(user1Address, secretKey, timestamp).send({
    from: user1Address,
    gas: gasEstimate1
});

    //await SC.methods.registerKey(user3Address, secretKey, timestamp).send({ from: user3Address });
    //console.log(`audit rport: ${auditReportHash}`);
    const auditLog = await SC.methods.auditLogs(user3Address).call();
 //console.log("Audit Log:", auditLog);

 await SC.methods.setExpectedHash(data).send({
    from: user3Address,
    gas: 3000000,
});

 //const auditData = await SC.methods.receiveAuditReport(user3Address, auditReportHash).send({
    //from: user3Address, // Ensure you specify the sender's address
   // gas: 3000000, // Set an appropriate gas limit
//});

//console.log("Audit data:", auditData);
const auditData = await SC.methods.receiveAuditReport(data, auditReportHash).call({
    from: user3Address,
});

//console.log("Hash verification result:", auditData);

    const receivedData = await SC.methods.receiveDataFromUser(user1Address).call();
    //console.log("receive result:", receivedData);
    // Step 8: SC checks for consistency and double-spending
    const isConsistent = checkConsistency(auditData, receivedData);
    //console.log("receive result:", isConsistent);
    if (!isConsistent) {
        await SC.methods.sendBlockNotification(user1Address, 'Double-spending detected').send({ from: user1Address });
        console.log('Double-spending detected!');

        // User1's income becomes 0 if double-spending is detected
        userIncome = 0;
    }

    // Step 9: User2 from Cside sends an audit report to SC
    const data2= 'User2 Audit Report Data';
    //const auditReportHash = web3.utils.keccak256(data);
    //console.log("Audit Report Hash (JS):", auditReportHash);

    const user2AuditReportHash = web3.utils.keccak256(data2);
    //console.log("user2 Audit Report Hash (JS):", user2AuditReportHash);
    const auditData1 = await SC.methods.receiveAuditReport(data2, user2AuditReportHash).call({
        from: user2Address,
    });
    //console.log("Hash verification result:", auditData1);
    //await SC.methods.receiveAuditReport(user2Address, user2AuditReportHash).send({ from: user2Address });

    // Step 10: SC compares the signatures from User1 and User2
    const user1Signature = await SC.methods.getSignature(user1Address).call();
    const user2Signature = await SC.methods.getSignature(user2Address).call();
    //console.log("User 1 Signature:", user1Signature);
    //console.log("User 2 Signature:", user2Signature);
    // Step 11: SC detects double-spending (if signatures match)
    if (user1Signature === user2Signature) {
        await SC.methods.sendBlockNotification(user1Address, 'Detected double-spending attempt').send({ from: user1Address });
        console.log('Double-spending detected, User1\'s income is 0');
        userIncome = 0; // User1's income becomes 0 if signatures match
    } else {
        console.log('No double-spending detected');
    }

    
    // Step 12: Timestamp Manipulation Check - Only sometimes (randomly triggered)
    const randomChance = Math.random();
    const timestampManipulationOccurs = randomChance < 0.3;  // 30% chance for timestamp manipulation to occur

    if (timestampManipulationOccurs) {
        const manipulatedTimestamp = Date.now(); // Simulate attacker generating a slightly different timestamp
        const timestampDifference = Math.abs(timestamp - manipulatedTimestamp);

        const allowedTimestampDifference = 1000; // 1-second tolerance for timestamp difference
        if (timestampDifference < allowedTimestampDifference) {
            console.log('Timestamp manipulation detected!');
            userIncome = 20;  // Increase income to 20 if the attacker bypasses the timestamp uniqueness check
        }
    }
    // Output the total income of User1
    console.log(`Total income for User1 in scenario ${scenarioId}: ${userIncome}`);
}

// Helper function to simulate Paillier encryption (you would use an actual Paillier encryption implementation)
function encryptDataWithPaillier(data) {
    // Placeholder encryption logic
    return web3.utils.sha3(JSON.stringify(data)); // Simulate encryption by hashing
}

// Helper function to check consistency of audit data
function checkConsistency(auditData, receivedData) {
    // Placeholder consistency check (real implementation would compare data hashes, etc.)
    return auditData === receivedData;
}

// Loop to run the scenario 10 times
async function runMultipleScenarios() {
    for (let i = 1; i <= 4; i++) {
        await runScenario(i);
    }
}

runMultipleScenarios();
