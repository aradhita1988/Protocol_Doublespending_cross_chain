const Cmain = artifacts.require("Cmain");
const Cside = artifacts.require("Cside");
const SC = artifacts.require("SC");

module.exports = async function (deployer, network, accounts) {
    // Deploy the SC contract
    await deployer.deploy(SC);
    const scInstance = await SC.deployed();
    console.log("SC contract deployed to:", scInstance.address); // Log the SC contract address

    // Deploy the Cmain contract with the SC contract address
    await deployer.deploy(Cmain, scInstance.address);
    const cmainInstance = await Cmain.deployed();
    console.log('Cmain contract deployed to:', cmainInstance.address); // Log the Cmain contract address

    // Set the Cmain address in the SC contract
    await scInstance.setCmainAddress(cmainInstance.address);
    console.log('Cmain address set in SC contract.');

    // Deploy the Cside contract with the SC contract address
    await deployer.deploy(Cside, scInstance.address);
    const csideInstance = await Cside.deployed();
    console.log('Cside contract deployed to:', csideInstance.address); // Log the Cside contract address

    // Optionally, you can verify that the SC contract is correctly set in Cmain and Cside
    const cmainScAddress = await cmainInstance.SCAddress();
    console.log('SC address in Cmain contract:', cmainScAddress);

    const csideScAddress = await csideInstance.SCAddress();
    console.log('SC address in Cside contract:', csideScAddress);
};
