// Import required libraries
const Web3 = require('web3');
const web3 = new Web3('http://localhost:7545'); // Example connection to Ganache
const SCABI = require('./build/contracts/SC.json').abi;
const SCaddress = web3.utils.toChecksumAddress("0xd649158a754233455F5c97DbAD47eCa1FA1Fc31e");
const SC = new web3.eth.Contract(SCABI, SCaddress);
const primeP = 37; 
const elliptic = require('elliptic');
const Paillier = require('paillier-bigint'); // Import Paillier encryption library
const { generateRandomKey } = require('paillier-bigint'); // Import the required function
const user1Address = '0x31035007e43527cf6441BD6D5dd56901590A9593';
const user2Address = '0x064f9e2cEe37128E29350F4B1dC0425a050ef3B3';
const user3Address = '0xFc3db1a0c26Aa06de2D50A11780da42112aeAe38';
const user4Address = '0xcBeCac8b1196db53939f12bbbe38F72042c4E4C9';
const Cmainaddress = "0x777BBDf6a5ebA52e3fef8EA7275C64ff52216588"; // Cmain contract address
const CmainABI = require('./build/contracts/Cmain.json').abi;

const Csideaddress = "0x3Be6FEc1248E6fF516605691dA4B58cB53518513"; // Cside contract address
const CsideABI = require('./build/contracts/Cside.json').abi;
// Initialize secp256k1 elliptic curve for ECDSA
const ecdsa = new elliptic.ec('secp256k1');
const Cmain = new web3.eth.Contract(CmainABI, Cmainaddress);
const Cside = new web3.eth.Contract(CsideABI, Csideaddress);
// Blockchain simulation (Cmain and Cside)
let CmainN = { nodes: [user1Address, user2Address], transactions: [] };
let CsideN = { nodes: [user3Address, user4Address], transactions: [] };

// Variables
let targetGroup = [user3Address, user4Address]; // Add more vulnerable nodes
let attackerControlledNodes = ['AttackerNode', user1Address, user3Address]; // Expand attacker-controlled nodes

let attackerIncome = 0; // Track attacker income

// Helper function to check node connectivity (simplified)
function isWeaklyConnected(node) {
    return node !== user1Address; // Example: 'User1' is considered more connected
}
function shouldIsolatedNodeAct() {
    return Math.random() > 0.3; // 70% chance the isolated node will act
}

// Step 1: Vulnerable Node Identification
function identifyVulnerableNodes(chain) {
    targetGroup = chain.nodes.filter(node => isWeaklyConnected(node));
}

// Step 2: Node Isolation
function isolateTargetGroup(chain) {
    chain.nodes.forEach(node => {
        if (targetGroup.includes(node)) {
            node.isIsolated = true;
            node.connectivity = 0; // Mark node as isolated
            console.log(`${node} is isolated.`);
        }
    });
}

function manipulateTimestamp(originalTimestamp, offset) {
    const randomChance = Math.random(); // Random value between 0 and 1
    const manipulationChance = Math.random; // 80% chance of timestamp manipulation for more success
    if (randomChance <= manipulationChance) {
        console.log("Timestamp manipulation occurred.");
        return originalTimestamp + offset; // Apply offset to manipulate the timestamp
    }
    console.log("No timestamp manipulation.");
    return originalTimestamp; // No manipulation, return original timestamp
}

// Improved Isolation Check
function isIsolated(node) {
    return targetGroup.includes(node) && node.isIsolated === true;
}

function isDoubleSpendingDetected(user1Signature, user2Signature) {
    const randomThreshold = Math.random(); // Generates a number between 0 and 1
   // const detectionProbability = 0.7; // 70% chance to detect double-spending
    return user1Signature === user2Signature ;
}

function simulateNetworkDelay(callback) {
    const delay = Math.random() * 5000; // Delay up to 5 seconds
    setTimeout(callback, delay);
}

// Simulate Attack with Failures
async function runScenario(attacks) {
    for (let i = 1; i <= attacks; i++) {
        console.log(`\n--- Simulating Attack ${i} ---`);

        // Step 1: Identify vulnerable nodes
        identifyVulnerableNodes(CsideN);

        // Step 2: Isolate vulnerable nodes
        isolateTargetGroup(CsideN);

        // Step 3: User1 requests secret key from SC
        await Cmain.methods.requestSecretKey(user1Address).send({ from: user1Address });
        const secretKey = Math.floor(Math.random() * (primeP - 1)) + 1;  // Random key in range 1 to P-1
        let timestamp = Date.now();
        
        // Step 4: Random chance for time manipulation
        const timeManipulationChance = Math.random(); // Random chance for time manipulation
        let success = false;
        
        if (timeManipulationChance <= 0.3) {
            // 30% chance for time manipulation
            timestamp = manipulateTimestamp(timestamp, 1000); // Manipulate by 1000ms (1 second)
            success = true;  // If time manipulation occurs, the attack is more likely to succeed
        } else {
            
            success = false;
        }

        await SC.methods.registerKey(user1Address, secretKey, timestamp).send({
            from: user1Address,
            gas: 3000000 // Adjust this value as needed
        });

        // Step 5: Generate ECDSA signature using private key and secret key
        const secretKeyHex = '0x' + BigInt(secretKey).toString(16).padStart(64, '0');
        try {
            const account = web3.eth.accounts.privateKeyToAccount(secretKeyHex);
            console.log(`Account Address: ${account.address}`);
        } catch (err) {
            console.error(`Private key validation failed: ${err.message}`);
        }

        const message = 'Transaction Data';
        const amount = web3.utils.toWei('0.1', 'ether');
        const signature = await web3.eth.accounts.sign(message, secretKeyHex);

        // Step 6: Send conflicting transactions to isolated nodes
        const packedData = web3.eth.abi.encodeFunctionCall({
            name: 'transfer', // Adjust to your contract function
            type: 'function',
            inputs: [
                { type: 'address', name: 'recipient' },
                { type: 'uint256', name: 'amount' }
            ]
        }, [user2Address, amount]);

        const gasEstimate = await Cmain.methods.sendTransaction(user2Address, packedData).estimateGas({ from: user1Address });
        await Cmain.methods.sendTransaction(user2Address, packedData).send({
            from: user1Address,
            gas: gasEstimate
        });

        // Step 7: Send conflicting transaction to User3 (Isolated node)
        simulateNetworkDelay(async () => {
            if (isIsolated(user3Address) && shouldIsolatedNodeAct()) {
                const conflictingTransaction = web3.eth.abi.encodeFunctionCall({
                    name: 'transfer',
                    type: 'function',
                    inputs: [
                        { type: 'address', name: 'recipient' },
                        { type: 'uint256', name: 'amount' }
                    ]
                }, [user4Address, amount]);

                await Cside.methods.sendTransaction(user4Address, conflictingTransaction).send({
                    from: user3Address,  // Using the isolated user3 to send a conflicting transaction
                    gas: gasEstimate
                });
            }
        });

        // Step 8: Attacker receives conflicting report and tries to propagate the attack
        if (isIsolated(user3Address)) {
            await SC.methods.sendBlockNotification(user1Address, 'Double-spending detected').send({ from: user1Address });
            console.log('Eclipse-based Double-spending detected!');
        }

        // Step 9: User2 from Cside sends an audit report to SC
        const user2AuditReportHash = web3.utils.keccak256('User2 Audit Report Data');
        const gasEstimate22 = await SC.methods.receiveAuditReport('User2 Audit Report Data', user2AuditReportHash).estimateGas({ from: user2Address });
        console.log("Gas estimate:", gasEstimate22);

        const auditData1 = await SC.methods.receiveAuditReport('User2 Audit Report Data', user2AuditReportHash).send({
            from: user2Address,
            gas: gasEstimate22
        });

        // Step 10: SC compares the signatures from User1 and User2
        const gasEstimate23 = await SC.methods.getSignature(user1Address).estimateGas({ from: user1Address });
        const user1Signature = await SC.methods.getSignature(user1Address).send({
            from: user1Address,
            gas: gasEstimate23
        });

        const gasEstimate24 = await SC.methods.getSignature(user2Address).estimateGas({ from: user2Address });
        const user2Signature = await SC.methods.getSignature(user2Address).send({
            from: user2Address,
            gas: gasEstimate24
        });

        // Step 11: SC detects double-spending (if signatures match)
        let attackResults = [];

        async function logAttackOutcome(attackNumber, success) {
            attackResults.push({ attackNumber, success });
            console.log(`Attack ${attackNumber}: ${success ? 'Success' : 'Failure'}`);
        }

        // After Step 11:
        if (isDoubleSpendingDetected(user1Signature, user2Signature)) {
            await SC.methods.sendBlockNotification(user1Address, 'Double-spending detected').send({ from: user1Address });
            console.log('Double-spending detected!');
            attackerIncome = 0;  // Attacker gains no income if double-spending is detected
            logAttackOutcome(i, false);
            console.log('attacker income', attackerIncome);
        } else {
            // If no double-spending detected, the attacker succeeds
            if (success) {
                attackerIncome = 20; // Attacker earns 20 if time manipulation was successful
                logAttackOutcome(i, true);
            } else {
                attackerIncome = 0;  // If no time manipulation, attacker earns nothing
                logAttackOutcome(i, false);
            }
            console.log('attacker income', attackerIncome);
        }
    }
}

// Run the scenario with the number of attacks you'd like to simulate
runScenario(10);
