const Csuper = artifacts.require("Csuper");
const Cmain = artifacts.require("Cmain");
const Cside = artifacts.require("Cside");

module.exports = async function (deployer) {

  // 1️⃣ Deploy Csuper
  await deployer.deploy(Csuper);
  const csuperInstance = await Csuper.deployed();
  console.log("Csuper deployed at:", csuperInstance.address);

  // 2️⃣ Deploy Cmain (pass Csuper address)
  await deployer.deploy(Cmain, csuperInstance.address);
  const cmainInstance = await Cmain.deployed();
  console.log("Cmain deployed at:", cmainInstance.address);

  // 3️⃣ Deploy Cside (pass Csuper address if required)
  await deployer.deploy(Cside, csuperInstance.address);
  const csideInstance = await Cside.deployed();
  console.log("Cside deployed at:", csideInstance.address);
};
