const { Web3 } = require("web3");
const { MerkleTree } = require("merkletreejs");
const keccak256 = require("keccak256");

const web3Main = new Web3("http://127.0.0.1:7545"); // Cmain + Csuper
const web3Side = new Web3("http://127.0.0.1:7546"); // Cside


// ================= CONTRACTS =================
const Csuper = new web3Main.eth.Contract(
  require("./build/contracts/Csuper.json").abi,
  "0x18F9B9Ee1e61b9fA8a162EAb49D514deE09aFc7e"   // deployed on 7545
);

const Cmain = new web3Main.eth.Contract(
  require("./build/contracts/Cmain.json").abi,
  "0xa257a0b6DCD327291Cb2e107e00b25BA663c6962"    // deployed on 7545
);

const Cside = new web3Side.eth.Contract(
  require("./build/contracts/Cside.json").abi,
  "0x4D2e7544fE3B804f6510E198d9423B06d806D3f2"    // deployed on 7546
);

// ================= METRICS =================
const metrics = {
  startTime: Date.now(),
  crossChainLatency: [],
  computationDelay: [],
  detectionLatency: [],
  totalTransactions: 0,
  communicationBytes: 0,
  attackAttempts: 0,
  successfulAttacks: 0
};

const sleep = ms => new Promise(r => setTimeout(r, ms));

const avg = arr =>
  arr.length ? arr.reduce((a, b) => a + b) / arr.length : 0;

// ================= MERKLE ROOT =================
function buildMerkleRoot(tx, ts, pk, sk) {
  const leaves = [
    tx,
    ts.toString(),
    pk,
    keccak256(sk.toString())
  ].map(x => keccak256(x));

  const tree = new MerkleTree(leaves, keccak256, { sortPairs: true });
  return tree.getRoot();
}

// ================= SIMULATION =================
async function runSimulation(rounds) {
  const accMain = await web3Main.eth.getAccounts();
  const accSide = await web3Side.eth.getAccounts();

  const user1 = accMain[0]; // Cmain user
  const user2 = accSide[0]; // Cside user

  for (let i = 0; i < rounds; i++) {
    const P = 1019;

    // ---- Secret key request ----
    const t0 = Date.now();
    const receiptSK = await Csuper.methods
      .requestSecretKey(P)
      .send({ from: user1, gas: 300000 });

    const SK = await Csuper.methods.secretKeys(user1).call();
    metrics.computationDelay.push(Date.now() - t0);

    // ---- Merkle construction ----
    const ts = Date.now();
    const rootMain = buildMerkleRoot("PAY_50", ts, user1, SK);

    // ---- Submit to Cmain ----
    const start = Date.now();
    await Cmain.methods.submitBatch(rootMain).send({ from: user1 });

    // ---- Eclipse attack attempt ----
    const attack = Math.random() < 0.3;
    metrics.attackAttempts++;

    let rootSide = rootMain;
    if (attack) {
      await sleep(3000); // eclipse delay
      rootSide = buildMerkleRoot("DOUBLE", ts, user1, SK);
    }

    // ---- Submit to Cside ----
    await Cside.methods.submitBatch(rootSide).send({ from: user2 });

    // ---- Audit ----
    const auditStart = Date.now();
    const receipt = await Csuper.methods
      .auditBatches(i * 2 + 1, i * 2 + 2)
      .send({ from: user1 });

    metrics.crossChainLatency.push(Date.now() - start);
    metrics.totalTransactions++;
    metrics.communicationBytes += 128;

    if (receipt.events?.EclipseAttackDetected) {
      metrics.detectionLatency.push(Date.now() - auditStart);
    } else if (attack) {
      metrics.successfulAttacks++;
    }
  }
}

// ================= RESULTS =================
function printResults() {
  const duration = (Date.now() - metrics.startTime) / 1000;

  console.log("\n=========== TWO-CHAIN RELAY RESULTS ===========");
  console.log("Average Cross-Chain Latency (ms):",
    avg(metrics.crossChainLatency).toFixed(2));
  console.log("Average Computation Delay (ms):",
    avg(metrics.computationDelay).toFixed(2));
  console.log("Average Detection Latency (ms):",
    avg(metrics.detectionLatency).toFixed(2));
  console.log("Transaction Throughput (tx/sec):",
    (metrics.totalTransactions / duration).toFixed(2));
  console.log("Communication Overhead (bytes):",
    metrics.communicationBytes);
  console.log("Attack Success Rate:",
    (metrics.successfulAttacks / metrics.attackAttempts).toFixed(2));
}

// ================= RUN =================
(async () => {
  await runSimulation(50);
  printResults();
})();
