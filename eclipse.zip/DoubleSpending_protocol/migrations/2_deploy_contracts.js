const Csuper = artifacts.require("Csuper");
const Cmain = artifacts.require("Cmain");
const Cside = artifacts.require("Cside");

module.exports = async function (deployer) {
  await deployer.deploy(Csuper);
  const csuper = await Csuper.deployed();

  await deployer.deploy(Cmain, csuper.address);
  await deployer.deploy(Cside, csuper.address);
};

